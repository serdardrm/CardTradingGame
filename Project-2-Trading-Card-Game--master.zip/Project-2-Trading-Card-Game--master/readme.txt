Bir oyuncunun bir bilgisayarla yada bilgisayarın bilgisayarla savaşa bileceği bir kart oyunudur. Çalışma mantığı kısaca:
1. Her iki oyuncuya destedeki karıştırılmış karttan ellerinde 3 tane olacak şekilde kart dağıtılır.
2. Oyuncular birer kart oynar.Oynan kartlardan hasarı büyük olan kart oyuncusuna 5 puan kazandırır.
3. Daha sonra oyuncualar desteden kart çeker ve bu döngü destede ve elde kart kalmayana kadar devam eder.
4. Kartlar bittiğinde en yüksek skora sahip oyuncu oyunu kazanır.